<template>
  <div>
    <h3>{{cardData.title || cardData.name}}</h3>
    <h4>{{cardData.original_title || cardData.original_name}}</h4>
    <img v-if="flags.includes(cardData.original_language)" 
        :src="require(`../assets/img/${cardData.original_language}.png`)" alt="">
    <p v-else>Lingua: {{cardData.original_language}}</p>
    <p>{{cardData.vote_average}}</p>
    <hr>
  </div>
</template>

<script>
export default {
  name: 'CardComp',
  data(){
    return{
      flags:['it','en']
    }
  },
  props:{
    cardData: Object
  }
}
</script>

<style lang="scss" scoped>

</style>