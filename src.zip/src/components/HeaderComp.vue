<template>
  <header>
    <input @keyup.enter="startSearch" v-model.trim="titleToSerach" type="text" >
    <select v-model="typeToSearch" @change="startSearch">
      <option value="all">All</option>
      <option value="movie">Movie</option>
      <option value="tv">Tv</option>
    </select>
  </header>
</template>

<script>
export default {
  name: 'HeaderComp',
  data(){
    return{
      titleToSerach: '',
      typeToSearch: 'all'
    }
  },
  methods:{
    startSearch(){
      this.$emit('startSearch',this.titleToSerach, this.typeToSearch);
      this.titleToSerach = '';
    }
  }
}
</script>

<style lang="scss" scoped>

</style>